package juego;

public class Proyectil {
	// Atributos privados
	private double x;
	private double y;
	private double velocidad;
	private int direccion; // Dirección en la que avanza
	private double diametro;

	// Constructor
	public Proyectil(double x, double y, int direccion) {
		this.x = x;
		this.y = y;
		this.direccion = direccion;
	}

	// Métodos a implementar:
	// - avanzar()
	// - dibujarse(Entorno entorno)
	// - fueraDeLimites(Entorno entorno)
	// - colisionaCon(Enemigo enemigo)
	// - getters y setters
}
