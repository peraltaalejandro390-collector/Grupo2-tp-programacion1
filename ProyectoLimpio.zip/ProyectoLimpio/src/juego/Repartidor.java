package juego;

public class Repartidor {
	// Atributos privados
	private double x;
	private double y;
	private double ancho;
	private double alto;
	private double velocidad;
	private int vidas;
	private int ultimaDireccion; // 0: arriba, 1: abajo, 2: izquierda, 3: derecha

	// Constructor
	public Repartidor(double x, double y) {
		this.x = x;
		this.y = y;
	}

	// Métodos a implementar:
	// - moverArriba(Ciudad ciudad)
	// - moverAbajo(Ciudad ciudad)
	// - moverIzquierda(Ciudad ciudad)
	// - moverDerecha(Ciudad ciudad)
	// - dibujarse(Entorno entorno)
	// - perderVida()
	// - getters y setters
}
