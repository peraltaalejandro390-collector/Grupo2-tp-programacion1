package juego;

import java.awt.Color;
import entorno.Entorno;
import entorno.InterfaceJuego;

public class Juego extends InterfaceJuego {
	// El objeto Entorno que controla el tiempo y otros
	private Entorno entorno;

	// Variables y métodos propios de cada grupo (atributos privados a usar)
	private Ciudad ciudad;
	private Repartidor repartidor;
	private Enemigo[] enemigos;
	private Proyectil proyectil;
	private Bomba[] bombas;
	private Pedido pedidoActual;

	// Estadísticas y estados
	private int tiempoTranscurrido;
	private int pedidosEntregados;
	private int pedidosPerdidos;
	private int enemigosEliminados;

	Juego() {
		// Inicializa el objeto entorno
		this.entorno = new Entorno(this, "Delivery Rush - Programacion I UNGS", 800, 600);

		// Inicializar lo que haga falta para el juego
		// ...

		// Inicia el juego!
		this.entorno.iniciar();
	}

	/**
	 * Durante el juego, el método tick() será ejecutado en cada instante y 
	 * por lo tanto es el método más importante de esta clase. Aquí se debe 
	 * actualizar el estado interno del juego para simular el paso del tiempo 
	 * (ver el enunciado del TP para mayor detalle).
	 */
	public void tick() {
		// Procesamiento de un instante de tiempo
		// ...

	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		Juego juego = new Juego();
	}
}
